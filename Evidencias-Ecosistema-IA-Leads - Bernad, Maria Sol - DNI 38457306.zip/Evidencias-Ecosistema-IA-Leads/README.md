# Evidencias --- Ecosistema IA Leads

Proyecto final de automatización inteligente para gestión de leads con
n8n, OpenAI, Airtable y Gmail.

## Objetivo de las pruebas

Se realizaron cinco escenarios para validar el funcionamiento del flujo
principal, las decisiones Human-in-the-Loop, las validaciones de
entrada, el manejo de errores y la clasificación realizada por IA.

  -----------------------------------------------------------------------
  Escenario               Validación              Resultado observado
  ----------------------- ----------------------- -----------------------
  1\. Caso exitoso        Lead válido → IA →      El flujo completó la
  aprobado                aprobación humana →     ruta positiva, la
                          envío                   propuesta fue aprobada,
                                                  enviada y el registro
                                                  quedó como
                                                  Enviado/Aprobado.

  2\. Rechazo humano      Lead válido → IA →      La decisión humana
                          revisión humana →       derivó por la ruta de
                          rechazo                 rechazo; Airtable
                                                  registró Rechazado y no
                                                  se ejecutó el envío al
                                                  cliente.

  3\. Datos incompletos / Validación previa al    La validación derivó el
  mensaje corto           procesamiento por IA    registro por la rama
                                                  False hacia el
                                                  tratamiento de datos
                                                  incompletos, evitando
                                                  continuar con IA y
                                                  aprobación.

  4\. Error de IA         Falla durante el        Se generó un error
                          procesamiento/salida    controlado en el
                          estructurada            procesamiento de IA y
                                                  quedó evidencia del
                                                  fallo y del registro de
                                                  error en Airtable.

  5\. Clasificación de    Diferentes solicitudes  La IA clasificó
  prioridad               comerciales             solicitudes con
                                                  diferentes prioridades
                                                  (por ejemplo Alta y
                                                  Media) y guardó
                                                  prioridad, resumen y
                                                  propuesta en Airtable.
  -----------------------------------------------------------------------

## Evidencia general

La carpeta `00-evidencia-general` contiene una captura del workflow
completo de n8n y evidencia de la configuración de aprobación
Human-in-the-Loop.

## Escenario 1 --- Caso exitoso aprobado

**Objetivo:** comprobar el recorrido completo de un lead válido.

**Resultado esperado:** creación del lead, análisis por IA, generación
de salida estructurada, aprobación humana, respuesta al cliente y
actualización final en Airtable.

**Resultado observado:** exitoso. El flujo alcanzó la rama de aprobación
y envío; Airtable muestra registros con Estado `Enviado`, Prioridad IA y
Aprobación Humana `Aprobado`.

## Escenario 2 --- Rechazo humano

**Objetivo:** validar que una propuesta rechazada por una persona no sea
enviada automáticamente.

**Resultado esperado:** la respuesta HITL debe ofrecer
aprobación/rechazo; al rechazar, el flujo debe ir por la rama negativa y
registrar la decisión.

**Resultado observado:** exitoso. La configuración HITL contempla
`Approve and Disapprove` y Airtable registra el caso como `Rechazado`.

## Escenario 3 --- Datos incompletos / mensaje corto

**Objetivo:** evitar enviar a IA solicitudes que no cumplen las
validaciones mínimas de entrada.

**Resultado esperado:** la condición de validación debe devolver False y
derivar el registro hacia la rama de datos incompletos.

**Resultado observado:** exitoso. La ejecución visible sigue la rama
False hacia `Create a record1` / registro de datos incompletos y no
continúa por el AI Agent.

## Escenario 4 --- Error de IA

**Objetivo:** comprobar la resiliencia del sistema ante un fallo del
procesamiento de IA.

**Resultado esperado:** el fallo debe quedar identificado y registrarse
como error para permitir trazabilidad.

**Resultado observado:** exitoso como prueba de unhappy path. Se capturó
un error del Structured Output Parser y Airtable contiene un registro
con Estado `Error` y detalle asociado.

## Escenario 5 --- Clasificación de prioridad

**Objetivo:** comprobar que la IA no asigne siempre la misma categoría y
que la clasificación se persista en la base.

**Resultado esperado:** solicitudes con distinto nivel de intención
comercial deben producir diferentes valores de prioridad y almacenar el
análisis.

**Resultado observado:** exitoso. En Airtable se observan registros
clasificados como `Alta` y `Media`, junto con Resumen IA y Propuesta IA.

## Conclusión

Las pruebas cubren happy path y unhappy paths: aprobación, rechazo,
validación de entrada, error de IA y variación de clasificación. En
conjunto demuestran que el ecosistema integra Gmail, n8n, OpenAI y
Airtable, incorpora Human-in-the-Loop antes del envío final y conserva
trazabilidad de los resultados.
